#include <stdio.h>

// gcc -Wall -o hello hello.c

int main(int argc, char *argv[]) {
    
    printf("Hello cs201!\n");

    return 0;
}
